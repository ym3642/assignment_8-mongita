from mongita import MongitaClientDisk
import os, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
client = MongitaClientDisk(os.path.join(BASE_DIR, "mongita_data"))
db = client.bookstore
categories_col = db.category
books_col = db.book

# Strip internal ObjectId (_id) so json.dump works — Mongita's _id is not JSON serializable
def to_json(cursor):
    docs = list(cursor)
    for doc in docs:
        doc.pop("_id", None)
    return docs

json.dump(to_json(categories_col.find()), open("categories.json", "w"), indent=2)
json.dump(to_json(books_col.find()),      open("books.json",      "w"), indent=2)

print("Exported categories.json and books.json")
